import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import estoque from './Screens/Estoque';
import faleconosco from './Screens/FaleConosco';
import login  from './Screens/Login';

export default function App() {
  return (
    <View 
    estoque
    login
    faleconosco
    />
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
