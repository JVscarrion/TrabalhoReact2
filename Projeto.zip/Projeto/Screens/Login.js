import React from "react";
import { Text, Button, View , StyleSheet  } from "react-native";
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import estoque  from "./Estoque";
import faleconosco from "./FaleConosco";

const Stack = createNativeStackNavigator();

function MyStack() {
    return (
      <Stack.Navigator>
        <Stack.Screen name="Estoque" component={estoque} />
        <Stack.Screen name="FaleConosco" component={faleconosco} />
      </Stack.Navigator>
    );
  }
export default function login (){
    const navigation = useNavigation();
        return(
            <View>
                <NavigationOpacity>
                        <Text>Email</Text>
                        <Text>Senha</Text>
                </NavigationOpacity>
                <Button onPress={onPress} title="Entrar"/>   
            </View>
            
        )

    }