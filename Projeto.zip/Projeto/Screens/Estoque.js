import React from "react";
import { Text, Button, View , StyleSheet  } from "react-native";
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import React, { useState } from 'react';

const Stack = createNativeStackNavigator();


export default function estoque(){
    
    const [count, setCount] = useState(0);
    
    <View style={StyleSheet.container}>
    
        <Text>Tenis adidas Preto</Text>
        <image source={{uri: 'https://media.istockphoto.com/id/458068097/pt/foto/adidas-superstar.jpg?s=612x612&w=0&k=20&c=lIoCSOGBK66I4kIaPSJM76_WNV5YNwh9GZootyYDxFI='}}
        style={{width: 50, height: 50}}/>
        <Text>Tenis Adidas preto tradicional</Text>

        <Text>Tenis Nike Preto</Text>
        <image source={{uri: 'https://vizzent.vtexassets.com/arquivos/ids/549136/tenis-feminino-nike-court-vision-preto-dh3158-003-1-.jpg?v=638552033564170000'}}
        style={{width: 50, height: 50}}/>
        <Text>Tenis Nike com detalhes pretos e brancos versão tradicional</Text>

        <Text>Tenis Nike Branco </Text>
        <image source={{uri: 'https://images.tcdn.com.br/img/img_prod/680475/tenis_nike_court_vision_lo_be_feminino_white_10592_1_5395f734d31d536d28b24c97207c6396_20230614155332.png'}}
        style={{width: 50, height: 50}}/>
        <Text>Tenis Nike Branco tradicional</Text>

        <Text>Tenis Olympikus</Text>
        <image source={{uri: 'https://cdn.dooca.store/432/products/captura-de-tela-2024-06-11-120958_640x640+fill_ffffff.png?v=1718118713&webp=0'}}
        style={{width: 50, height: 50}}/>
        <Text>Tenis da Olympikus preto</Text>

        <Text>Tenis Adidas Branco </Text>
        <image source={{uri: 'https://anjuss.fbitsstatic.net/img/p/tenis-adidas-grand-court-2-0-branco-86396/319069-1.jpg'}}
        style={{width: 50, height: 50}}/>
        <Text>Tenis Adidas branco com listras pretas</Text>
        
        <button onClick={() => setCount(count + 1)}>
        +
        </button>
        <button onClick={() => setCount(count - 1)}>
        -
        </button>
        

    </View>

const styles = StyleSheet.create({
    container: {
      justifyContent: 'center'
    },
    
  });
}