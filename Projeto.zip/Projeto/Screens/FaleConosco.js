import React from "react";
import { Text, Button, View , StyleSheet  } from "react-native";


export default function faleconosco(){
    <View style={styles.container}>
        <image source={{uri: 'https://static.vecteezy.com/ti/vetor-gratis/p1/5439327-sapatilha-loja-logo-eps-vetor.jpg'}}
        style={{width: 50, height: 50}}/>
    <NavigationOpacity>
            <Text>Email</Text>
            <Text>Senha</Text>
    </NavigationOpacity> 
    </View>
    

}
